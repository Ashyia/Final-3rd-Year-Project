angular.module('app.controllers', [])
  
.controller('mainPageCtrl', function($scope) {

})
   
.controller('caloriesCtrl', function($scope) {

})
   
.controller('excerciseCtrl', function($scope) {

})
      
.controller('cardioCtrl', function($scope) {

})
 